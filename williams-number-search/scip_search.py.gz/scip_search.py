#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,math,random,re,sys,time
from pathlib import Path
from pyscipopt import Model, quicksum

N=1029

def load_rows(kind):
 p=Path('global_rows.json' if kind=='global' else 'split_rows.json')
 return json.loads(p.read_text())

def load_primes():
 vals=[int(s) for s in re.findall(r'\d+',Path('SET-1029-PRIMES.txt').read_text())]
 assert len(vals)==N
 return vals

def set_if(model,typ,name,val):
 try:
  {'int':model.setIntParam,'longint':model.setLongintParam,'real':model.setRealParam,'bool':model.setBoolParam,'char':model.setCharParam,'string':model.setStringParam}[typ](name,val)
  print('PARAM',name,val)
 except Exception as e: print('PARAM_SKIP',name,e)

def verify(x,rows,primes,out):
 if len(x)!=N or sum(x)<3 or sum(x)%2!=1:return False
 for r in rows:
  m=int(r['m']); b=int(r.get('b',0))%m
  if sum((int(a)%m)*z for a,z in zip(r['a'],x))%m!=b:return False
 sel=[p for p,z in zip(primes,x) if z]
 big=math.prod(sel)
 for p in sel:
  if (big-1)%(p-1) or (big+1)%(p+1):return False
 cert={'status':'VERIFIED_WILLIAMS_NUMBER','factor_count':len(sel),'selected_indices_zero_based':[i for i,z in enumerate(x) if z],'prime_factors':sel,'N':str(big)}
 Path(out).write_text(json.dumps(cert,indent=2))
 Path(out+'.factors.txt').write_text('\n'.join(map(str,sel))+'\n')
 Path(out+'.N.txt').write_text(str(big)+'\n')
 print('FOUND_VERIFIED',len(sel),out)
 return True

def main():
 ap=argparse.ArgumentParser()
 ap.add_argument('--kind',choices=['global','split'],default='global')
 ap.add_argument('--weight',type=int,default=515)
 ap.add_argument('--seed',type=int,default=1)
 ap.add_argument('--seconds',type=float,default=2800)
 ap.add_argument('--workers',type=int,default=4)
 ap.add_argument('--mode',choices=['default','feas','randomobj','nopresolve','nolp','aggressive','complement','branch'],default='default')
 ap.add_argument('--output',default='scip_certificate.json')
 args=ap.parse_args()
 rows=load_rows(args.kind); primes=load_primes(); rng=random.Random(args.seed)
 model=Model(f'williams_{args.kind}_{args.mode}_{args.seed}')
 model.hideOutput(False)
 set_if(model,'real','limits/time',args.seconds)
 set_if(model,'longint','limits/nodes',2_000_000_000)
 set_if(model,'int','limits/solutions',1)
 set_if(model,'int','parallel/maxnthreads',args.workers)
 set_if(model,'int','randomization/randomseedshift',args.seed)
 set_if(model,'int','randomization/permutationseed',args.seed*17+3)
 set_if(model,'int','randomization/lpseed',args.seed*31+7)
 if args.mode in ('feas','aggressive'):
  try:
   from pyscipopt import SCIP_PARAMEMPHASIS
   model.setEmphasis(SCIP_PARAMEMPHASIS.FEASIBILITY)
  except Exception as e: print('EMPHASIS_SKIP',e)
 if args.mode=='nopresolve':
  try:
   from pyscipopt import SCIP_PARAMSETTING
   model.setPresolve(SCIP_PARAMSETTING.OFF)
  except Exception as e: print('PRESOLVE_SKIP',e)
 if args.mode=='aggressive':
  try:
   from pyscipopt import SCIP_PARAMSETTING
   model.setHeuristics(SCIP_PARAMSETTING.AGGRESSIVE)
  except Exception as e: print('HEUR_SKIP',e)
 if args.mode=='nolp':
  set_if(model,'int','lp/solvefreq',-1)

 x=[model.addVar(vtype='B',name=f'x{i}') for i in range(N)]
 if args.weight>=0:
  model.addCons(quicksum(x)==args.weight,name='weight')
 else:
  k=model.addVar(lb=1,ub=(N-1)//2,vtype='I',name='odd_k')
  model.addCons(quicksum(x)==2*k+1,name='odd_weight')

 # Signed centered coefficients make the integer quotients much tighter.
 for ri,r in enumerate(rows):
  m=int(r['m']); b=int(r.get('b',0))%m
  aa=[]
  for z in r['a']:
   z=int(z)%m
   if z>m//2:z-=m
   aa.append(z)
  lo=sum(z for z in aa if z<0); hi=sum(z for z in aa if z>0)
  qlo=math.floor((lo-b)/m)-1; qhi=math.ceil((hi-b)/m)+1
  q=model.addVar(lb=qlo,ub=qhi,vtype='I',name=f'q{ri}')
  model.addCons(quicksum(z*xv for z,xv in zip(aa,x) if z)!=b+m*q,name=f'row{ri}')

 if args.mode in ('randomobj','complement','branch'):
  coeff=[rng.randint(-1000,1000) for _ in range(N)]
  if args.mode=='complement': coeff=[(1 if rng.random()<.5 else -1) for _ in range(N)]
  model.setObjective(quicksum(c*v for c,v in zip(coeff,x)),'minimize')
 else:
  model.setObjective(0.0)
 if args.mode=='branch':
  order=list(range(N));rng.shuffle(order)
  for rank,i in enumerate(order):
   try:model.chgVarBranchPriority(x[i],N-rank)
   except Exception:pass

 print('MODEL',args,'vars',model.getNVars(),'conss',model.getNConss(),flush=True)
 t=time.time(); model.optimize(); elapsed=time.time()-t
 status=str(model.getStatus()); print('STATUS',status,'solutions',model.getNSols(),'elapsed',elapsed,flush=True)
 if model.getNSols()>0:
  sol=model.getBestSol(); xx=[1 if model.getSolVal(sol,v)>0.5 else 0 for v in x]
  print('CANDIDATE_WEIGHT',sum(xx),flush=True)
  if verify(xx,load_rows('global'),primes,args.output):sys.exit(0)
  print('REJECTED_CANDIDATE',flush=True);sys.exit(3)
 sys.exit(2)
if __name__=='__main__':main()
